# 🎤 Guia Rápido de Apresentação - TCC

## ⏱️ Tempo Total: 10-15 minutos

---

## 📋 Checklist Pré-Apresentação

- [ ] PostgreSQL rodando
- [ ] Banco de dados criado
- [ ] `PopularBancoDados.java` executado
- [ ] Sistema testado (executar uma vez antes)
- [ ] Arquivos de exemplo criados (exports/, backups/)
- [ ] Código sem comentários
- [ ] Slides ou material de apoio preparado (opcional)

---

## 🎯 Roteiro Detalhado

### 1️⃣ INTRODUÇÃO (2 minutos)

**O que falar:**
- "Meu projeto é um sistema de gestão para construção civil"
- "Foca no ODS 8 - Trabalho Decente e Crescimento Econômico"
- "Gerencia 3 entidades principais: Trabalhadores, Canteiros e EPIs"
- "Atende todos os requisitos: CRUD, Streams, arquivos, serialização"

**O que mostrar:**
- Arquitetura do projeto (pasta src/)
- Estrutura de pacotes (model, dao, service, util)

---

### 2️⃣ CRUD - TRABALHADORES (3 minutos)

**Demonstração prática:**

1. **Cadastrar trabalhador:**
   ```
   Menu → 1. Gerenciar Trabalhadores → 1. Cadastrar
   
   Nome: Pedro Santos
   CPF: 12345678909 (mostrar validação funcionando)
   Função: Pedreiro
   Registro: 12345
   Contrato: CLT
   Canteiro: 1
   ```

2. **Listar todos:**
   ```
   Menu → 1. Gerenciar Trabalhadores → 2. Listar Todos
   (mostrar os 5 trabalhadores + o novo)
   ```

3. **Buscar por ID:**
   ```
   Menu → 1. Gerenciar Trabalhadores → 3. Buscar por ID
   ID: 1
   ```

4. **Atualizar:**
   ```
   Menu → 1. Gerenciar Trabalhadores → 4. Atualizar
   ID: 6 (o que acabou de criar)
   Nova função: Mestre de Obras
   ```

5. **Remover:**
   ```
   Menu → 1. Gerenciar Trabalhadores → 5. Remover
   ID: 6
   Confirmar: S
   ```

**O que destacar:**
- Validação de CPF funcionando
- Campos condicionais (CREA para engenheiros)
- Relacionamento com Canteiro

---

### 3️⃣ STREAMS API (2 minutos)

**Demonstração prática:**

```
Menu → 1. Gerenciar Trabalhadores → 6. Exemplos de Streams API
```

**Executar 3 exemplos:**

1. **Filtrar por função:**
   ```
   Opção: 1
   Função: Pedreiro
   (mostra apenas pedreiros)
   ```

2. **Contar por tipo de contrato:**
   ```
   Opção: 3
   (mostra: CLT: 4, PJ: 1, TEMPORARIO: 1)
   ```

3. **Listar apenas nomes:**
   ```
   Opção: 4
   (mostra lista ordenada de nomes)
   ```

**O que destacar:**
- "Uso de filter, map, collect do Streams API"
- "Total de 9 métodos implementados no TrabalhadorService"
- Mostrar código de 1 método (ex: filtrarPorFuncao)

---

### 4️⃣ EXPORTAÇÃO DE ARQUIVOS (2 minutos)

**Demonstração prática:**

1. **Exportar em JSON:**
   ```
   Menu → 5. Exportar Dados → 1. Exportar Trabalhadores
   Formato: 2. JSON
   Nome: trabalhadores_demo
   ```

2. **Mostrar arquivo gerado:**
   - Abrir `exports/trabalhadores_demo.json`
   - Mostrar estrutura JSON formatada

3. **Exportar em TXT:**
   ```
   Menu → 5. Exportar Dados → 3. Exportar EPIs
   Formato: 1. TXT
   Nome: epis_demo
   ```

4. **Mostrar arquivo TXT:**
   - Abrir `exports/epis_demo.txt`
   - Mostrar formatação com cabeçalho

**O que destacar:**
- "Uso do Jackson para JSON (não GSON)"
- "Suporte a LocalDate com jackson-datatype-jsr310"
- "3 formatos: TXT, JSON e BIN"
- "Caminho completo do arquivo é exibido"

---

### 5️⃣ BACKUP E SERIALIZAÇÃO (2 minutos)

**Demonstração prática:**

1. **Fazer backup:**
   ```
   Menu → 6. Backup e Restauração → 1. Fazer Backup
   (sistema salva em backups/trabalhadores.bak)
   ```

2. **Mostrar informações:**
   - Data/hora do backup
   - Quantidade de registros
   - Caminho do arquivo

3. **Restaurar backup:**
   ```
   Menu → 6. Backup e Restauração → 2. Restaurar Backup
   (sistema lê e mostra informações do backup)
   ```

**O que destacar:**
- "Serialização completa de objetos"
- "Inclui metadados (data/hora)"
- "Implementa Serializable nas entidades"

---

### 6️⃣ RELATÓRIOS (2 minutos)

**Demonstração prática:**

1. **Trabalhadores por Canteiro:**
   ```
   Menu → 4. Relatórios → 1. Trabalhadores por Canteiro
   (mostra agrupamento usando Streams)
   ```

2. **EPIs Vencidos:**
   ```
   Menu → 4. Relatórios → 2. EPIs Vencidos
   (mostra o EPI vencido criado nos dados de teste)
   ```

3. **Estatísticas Gerais:**
   ```
   Menu → 4. Relatórios → 3. Estatísticas Gerais
   (mostra totais e contagens)
   ```

**O que destacar:**
- "Uso de Streams para agrupamento"
- "Filtros com predicados (EPIs vencidos)"
- "Relatórios úteis para gestão"

---

### 7️⃣ CONCLUSÃO (2 minutos)

**Recapitular requisitos atendidos:**

✅ **CRUD completo** - Demonstrado com Trabalhadores
✅ **Streams API** - 9 métodos implementados
✅ **Arquivos** - TXT, JSON (Jackson), BIN
✅ **Serialização** - Sistema de backup
✅ **Relatórios** - 3 relatórios funcionais
✅ **Interface Console** - Menu organizado
✅ **Validações** - CPF, CREA, Registros
✅ **JPA + Hibernate** - PostgreSQL

**Destacar boas práticas:**
- Padrão DAO para acesso a dados
- Camada de Service para lógica de negócio
- Validações profissionais
- Código limpo e organizado
- Arquitetura escalável

**Perguntas frequentes (preparar respostas):**

1. **"Por que Jackson e não GSON?"**
   - "Foi o que o professor ensinou durante o semestre"
   - "Jackson tem melhor suporte a Java 8+ (LocalDate, etc)"

2. **"Por que 3 entidades?"**
   - "Projeto anterior tinha 20+ e ficou muito complexo"
   - "Versão simplificada mantém todos os requisitos mas é mais clara"

3. **"Como funciona a validação de CPF?"**
   - Mostrar código do ValidacaoUtil
   - Explicar algoritmo dos dígitos verificadores

4. **"Qual a diferença entre TXT, JSON e BIN?"**
   - TXT: legível, formatado para humanos
   - JSON: estruturado, interoperável
   - BIN: binário, serialização Java

---

## 💡 Dicas Importantes

### Durante a apresentação:

✅ **Fale devagar e com clareza**
✅ **Mostre o código quando relevante**
✅ **Explique o "porquê" das escolhas**
✅ **Demonstre segurança no que fez**
✅ **Prepare-se para perguntas sobre Streams API**

### O que evitar:

❌ Não diga "não sei" - diga "vou verificar"
❌ Não fique apenas lendo código
❌ Não pule etapas importantes (Streams, Serialização)
❌ Não deixe de testar antes
❌ Não esqueça de mencionar ODS 8

---

## 🎬 Ordem de Execução

1. Abrir terminal
2. Executar sistema: `mvn exec:java -Dexec.mainClass="br.edu.utfpr.MenuConsoleSimplificado"`
3. Seguir roteiro acima
4. Ter IDE aberta em segundo plano para mostrar código
5. Ter pasta exports/ e backups/ abertas para mostrar arquivos

---

## 📊 Tempo por Seção

| Seção | Tempo | Prioridade |
|-------|-------|------------|
| Introdução | 2 min | Alta |
| CRUD | 3 min | Alta |
| Streams API | 2 min | **Crítica** |
| Exportação | 2 min | **Crítica** |
| Serialização | 2 min | **Crítica** |
| Relatórios | 2 min | Média |
| Conclusão | 2 min | Alta |

**Total:** 15 minutos

Se precisar reduzir para 10 minutos:
- Reduzir CRUD para 2 min (mostrar apenas cadastrar e listar)
- Reduzir Relatórios para 1 min (mostrar apenas 1 relatório)

---

## 🚀 Última Verificação

Antes de apresentar, execute esta sequência completa:

```bash
# 1. Popular banco
mvn exec:java -Dexec.mainClass="br.edu.utfpr.PopularBancoDados"

# 2. Executar sistema
mvn exec:java -Dexec.mainClass="br.edu.utfpr.MenuConsoleSimplificado"

# 3. Testar cada funcionalidade uma vez
```

---

## 🎯 Objetivo Final

Demonstrar que você:
- Entende POO e seus conceitos
- Sabe usar Streams API do Java 8+
- Domina JPA/Hibernate
- Conhece serialização e manipulação de arquivos
- Escreve código limpo e profissional
- Resolve problemas reais (ODS 8)

**Boa sorte! 🍀**
